export class MatchImageDto {
  matchId: number;
  imageURL: string;
}
