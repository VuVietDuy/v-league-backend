export class CreateVoteDto {
  userId: number;
  matchId: number;
  playerId: number;
}
