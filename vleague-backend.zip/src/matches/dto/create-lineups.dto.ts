export class CreateLineupsDto {
  id: number;
  matchId: number;
  clubId: number;
  playerId: number;
  isStarting: boolean;
}
